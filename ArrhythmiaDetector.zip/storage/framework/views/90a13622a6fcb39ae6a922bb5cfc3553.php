
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h2>Welcome to the page</h2>
                <p>Make sure to login or register if you don't have account</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Welcome'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\ArrhythmiaDetector\resources\views/guest.blade.php ENDPATH**/ ?>