
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h2>Doctor</h2>
            </div>
        </div>
        
        <div class="card mt-5">
            <div class="card-header">Daftar Pasien</div>
            <div class="card-body">
                <table class="table table-bordered table-sm table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Username</th>
                            <th scope="col">Address</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Emergency Phone</th>
                            <th scope="col">Age</th>
                            <th scope="col">Gender</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($index); ?></th>
                            <td><?php echo e($patient->username); ?></th>
                            <td><?php echo e($patient->address); ?></th>
                            <td><?php echo e($patient->phone); ?></th>
                            <td><?php echo e($patient->emergency_phone); ?></th>
                            <td><?php echo e($patient->age); ?></th>
                            <td><?php echo e($patient->gender); ?></th>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Doctor Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\ArrhythmiaDetector\resources\views/doctors/dashboard.blade.php ENDPATH**/ ?>