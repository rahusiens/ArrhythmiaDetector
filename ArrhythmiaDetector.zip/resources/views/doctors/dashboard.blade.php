@extends('layouts.app', ['title' => 'Doctor Dashboard'])
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h2>Doctor</h2>
            </div>
        </div>
        {{-- <ul class="list-group mt-4">
            @foreach ($patients as $index => $patient)
            <li class="list-group-item d-flex align-items-center justify-content-between">
                {{ $index+1 }}. {{ $patient->username }}
            </li>
            @endforeach
        </ul> --}}
        <div class="card mt-5">
            <div class="card-header">Daftar Pasien</div>
            <div class="card-body">
                <table class="table table-bordered table-sm table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Username</th>
                            <th scope="col">Address</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Emergency Phone</th>
                            <th scope="col">Age</th>
                            <th scope="col">Gender</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($patients as $index => $patient)
                        <tr>
                            <th scope="row">{{ $index }}</th>
                            <td>{{ $patient->username }}</th>
                            <td>{{ $patient->address }}</th>
                            <td>{{ $patient->phone }}</th>
                            <td>{{ $patient->emergency_phone }}</th>
                            <td>{{ $patient->age }}</th>
                            <td>{{ $patient->gender }}</th>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection