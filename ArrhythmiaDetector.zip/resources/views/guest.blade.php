@extends('layouts.app', ['title' => 'Welcome'])
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h2>Welcome to the page</h2>
                <p>Make sure to login or register if you don't have account</p>
            </div>
        </div>
    </div>
@endsection