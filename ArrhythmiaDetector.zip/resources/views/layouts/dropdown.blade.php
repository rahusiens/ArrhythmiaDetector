<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
      {{ Auth::user()->username }}
    </a>
    <ul class="dropdown-menu dropdown-menu-end">
      <li><a class="dropdown-item" href={{ $editRoute }}>Edit</a></li>
      <li>
        <form action={{ $logoutRoute }}" method="post">
          @csrf
          <button type="submit" class="dropdown-item">Logout</button>
        </form>
      </li>
      <li><hr class="dropdown-divider"></li>
      <li><a class="dropdown-item" href="#">Something else here</a></li>
    </ul>
  </li>