<div class="mb-2">
    <label for="address" class="form-label">Address</label>
    <input type="text" name="address" id="address" value="{{ old('address', $patient->address) }}" class="form-control @error('email') is-invalid @enderror">
    @error('address')
        <div class="text-danger mt-2">
            {{ $message }}
        </div>
    @enderror
</div>
<div class="mb-2">
    <label for="phone" class="form-label">Phone</label>
    <input type="text" name="phone" id="phone" value="{{ old('phone', $patient->phone) }}" class="form-control @error('email') is-invalid @enderror">
    @error('phone')
        <div class="text-danger mt-2">
            {{ $message }}
        </div>
    @enderror
</div>
<div class="mb-2">
    <label for="emergency_phone" class="form-label">Emergency Phone</label>
    <input type="text" name="emergency_phone" id="emergency_phone" value="{{ old('emergency_phone', $patient->emergency_phone) }}" class="form-control @error('email') is-invalid @enderror">
    @error('emergency_phone')
        <div class="text-danger mt-2">
            {{ $message }}
        </div>
    @enderror
</div>
<div class="mb-2">
    <label for="age" class="form-label">Age</label>
    <input type="text" name="age" id="age" value="{{ old('age', $patient->age) }}" class="form-control @error('email') is-invalid @enderror">
    @error('age')
        <div class="text-danger mt-2">
            {{ $message }}
        </div>
    @enderror
</div>
<div class="mb-2">
    <label for="gender" class="form-label">Gender</label>
    <input type="text" name="gender" id="gender" value="{{ old('gender', $patient->gender) }}" class="form-control @error('email') is-invalid @enderror">
    @error('gender')
        <div class="text-danger mt-2">
            {{ $message }}
        </div>
    @enderror
</div>
<button type="submit" class="btn btn-primary">{{ $button }}</button>