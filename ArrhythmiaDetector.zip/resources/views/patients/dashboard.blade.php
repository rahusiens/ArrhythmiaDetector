@extends('layouts.app', ['title' => 'Patient Dashboard'])
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h2>Patient</h2>
            </div>
        </div>
    </div>
@endsection