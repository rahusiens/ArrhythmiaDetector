@extends('layouts.app', ['title' => 'Patient Dashboard'])
@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card">
                    <div class="card-header">Update</div>
                    <div class="card-body">
                        <form action="{{ route('patient.edit') }}" method="post">
                            @method('put')
                            @csrf
                            @include('patients._form', ['button' => 'Update'])
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection